// Importa la librería Express, que sirve para crear servidores web de manera sencilla.
const express = require('express'); 
// Importa la librería Path, que permite trabajar con rutas de archivos y directorios en el sistema operativo.
const path = require('path'); 
//Libreria Mysql
const mysql = require('mysql');
// Crear instancia de la aplicación Express, que manejará las rutas y peticiones del servidor.
const app = express(); 
// Define el número de puerto en el que el servidor va a escuchar las solicitudes. Se usa el 3000.
const port = 3000; 

// Configurar la conexión a la base de datos
const connection = mysql.createConnection({
    host: '10.0.6.39',
    user: 'estudiante',
    password: 'Informatica-165',
    database: 'Ropa'
});
//Verificacion de errores para validar si la conexion es correcta
connection.connect((problema) => {
    if (problema) {
        console.error('Error de conexión a la base de datos: ' + problema.stack);
        return;
    }
    console.log('Conexión exitosa a la base de datos.');
});

// Iniciar el servidor en el puerto definido
app.listen(port, () => { 
    console.log('Servidor corriendo en http://localhost:3000'); 
    // Cuando el servidor empieza a escuchar, muestra en consola que está corriendo en localhost:3000.
});

// Configuro para que la aplicación inicie desde el directorio o carpeta "pagina_principal"
// __dirname es una variable que representa la ruta absoluta del directorio actual donde está este archivo.
// path.join une la ruta actual (__dirname) con la carpeta 'pagina_principal'.
app.use(express.static(path.join(__dirname, 'pagina_principal'))); 
// Envio los datos del formulario por url por procesar los datos enviados
app.use(express.urlencoded({ extended: true })); 

// Ruta POST que maneja el envío del formulario para guardar una película
app.post('/guardar_prenda', (request, response) => { 
    // Extrae los campos del formulario desde el cuerpo de la solicitud
    const { nombre, material, fecha, color, precio } = request.body; 
    // Consulta SQL para insertar una nueva película
    const sql = 'INSERT INTO Ropa (nombre, material, fecha, color, precio) VALUES (?, ?, ?, ?, ?)'; 
    // Ejecuta la consulta SQL con los valores extraídos
    connection.query(sql, [nombre, material, fecha, color, precio], (problema, result) => { 
        // Si ocurre un error al insertar, lanza una excepción (se detiene el servidor si no se maneja)
        if (problema) throw problema; 
        // Mensaje en consola indicando que la inserción fue exitosa
        console.log('Prenda insertada correctamente.'); 
        // Redirige al usuario a la página principal después de guardar la película
        response.redirect('/'); 
    });
});

// Ruta que responde a solicitudes GET en '/peliculas'
// Esta ruta será llamada desde el navegador (por ejemplo, al cargar listardatos.html)
app.get('/Ropa', (request, response) => {
    // Ejecuta una consulta SQL para obtener todos los registros de la tabla "Peliculas"
    connection.query('SELECT * FROM Ropa', (problema, rows) => {
        // Si ocurre un error durante la consulta (por ejemplo, error de conexión o sintaxis SQL), se lanza el error y se detiene la ejecución
        if (problema) throw problema;
        // Si la consulta fue exitosa, se envían los resultados (filas) al cliente que hizo la solicitud
        // Por defecto, se envía como JSON, ya que rows es un arreglo de objetos
        response.send(rows);
    });
});


// Define una ruta DELETE en Express para eliminar una película según su ID
app.delete('/eliminar_Ropa/:id', (request, response) => {
    // Extrae el parámetro 'id' desde la URL (por ejemplo: /eliminar_pelicula/5)
    const id = request.params.id;
    // Define la consulta SQL que eliminará la película cuyo ID coincida
    const sql = 'DELETE FROM Ropa WHERE id = ?';
    // Ejecuta la consulta SQL, pasando el ID como parámetro para evitar inyecciones SQL
    connection.query(sql, [id], (problema, result) => {
        // Si ocurre un error durante la ejecución de la consulta, se lanza el error
        if (problema) throw problema;
        // Si la eliminación fue exitosa, se muestra un mensaje en consola
        console.log('Prenda eliminada correctamente.');
        // Se responde al cliente con el código 200 (OK), indicando que la operación fue exitosa
        response.sendStatus(200);
    });
});

// --- Obtener datos de una película por su ID ---
app.get('/peliculas/:id', (req, res) => {
    const id = req.params.id; // Captura el ID desde la URL (por ejemplo: /peliculas/3)
    // Ejecuta una consulta SQL para buscar la película con ese ID
    connection.query('SELECT * FROM PRENDAS WHERE id = ?', [id], (err, result) => {
        if (err) {
            // Si ocurre un error al ejecutar la consulta, lo muestra en consola y responde con error 500
            console.error('Error al consultar:', err);
            return res.status(500).send('Error del servidor');
        }
        if (result.length === 0) {
            // Si no se encuentra ninguna película con ese ID, responde con error 404
            return res.status(404).send('Prenda no encontrada');
        }
        // Si se encuentra la película, la envía como respuesta en formato JSON
        res.json(result[0]);
    });
});


// --- Modificar datos de una película ---
app.post('/modificar_Producto', (req, res) => {
    // Extrae los datos del formulario que vienen en el cuerpo de la solicitud
    const { id, nombre, descripcion, fecha, categoria, precio } = req.body;
    // Consulta SQL para actualizar la película con los nuevos datos
    const sql = 'UPDATE Prendas SET nombre = ?, descripcion = ?, fecha = ?, categoria = ?, precio = ? WHERE id = ?';
    // Ejecuta la consulta, reemplazando los "?" por los valores del formulario
    connection.query(sql, [nombre, descripcion, fecha, categoria, precio, id], (err, result) => {
        if (err) {
            // Si hay un error al actualizar, lo muestra en consola y responde con error 500
            console.error('Error al modificar:', err);
            return res.status(500).send('Error del servidor');
        }
        // Si la modificación fue exitosa, muestra un mensaje en consola
        console.log('Poducto modificado ');
        // Redirecciona al usuario a la página donde se listan todas las películas
        res.redirect('/listardatos.html');
    });
});



