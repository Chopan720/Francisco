// Función para eliminar una película
function eliminarPrenda(id) {
    // Envia una solicitud HTTP DELETE al servidor para eliminar una película según su ID
    fetch('/eliminar_ropa/' + id, {
        method: 'DELETE' // Se especifica el método HTTP DELETE
    })
    // .then() se ejecuta cuando la solicitud se completa exitosamente (independiente de si el servidor respondió bien o mal)
    .then(function(response) {
        // Verifica si la respuesta del servidor fue exitosa 
        if (response.ok) {
            console.log('Prenda eliminada correctamente.');
            // Recarga la página para reflejar los cambios (actualizar la lista de películas)
            window.location.reload();
        } else {
            // Si el servidor respondió con un error (como 404 o 500), se muestra un mensaje en la consola
            console.error('Error al eliminar la prenda.');
        }
    })
    // .catch() captura cualquier error que ocurra durante la solicitud (por ejemplo, si el servidor no responde)
    .catch(function(error) {
        console.error('Error en la solicitud:', error);
    });
}
