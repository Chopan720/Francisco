// Referencias a los elementos del formulario
const nombre = document.getElementById("nombre");         // Campo de texto para el nombre
const correo = document.getElementById("correo");         // Campo de texto para el correo electrónico
const password = document.getElementById("password");     // Campo de texto para la contraseña

// Referencias a los elementos que muestran errores
const errorNombre = document.getElementById("error-nombre");       // Mensaje de error para el nombre
const errorCorreo = document.getElementById("error-correo");       // Mensaje de error para el correo
const errorPassword = document.getElementById("error-password");   // Mensaje de error para la contraseña

// Validación en tiempo real del campo "nombre"
nombre.addEventListener("input", () => {
  // Si el nombre tiene menos de 3 caracteres, se muestra un mensaje de error
  if (nombre.value.trim().length < 3) {
    errorNombre.textContent = "El nombre debe tener al menos 3 caracteres.";
  } else {
    // Si es válido, se borra el mensaje de error
    errorNombre.textContent = "";
  }
});

// Validación en tiempo real del campo "correo"
correo.addEventListener("input", () => {
  // Expresión regular para validar correos electrónicos
  const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Si el correo no cumple con el formato, se muestra un mensaje de error
  if (!regexCorreo.test(correo.value)) {
    errorCorreo.textContent = "Ingrese un correo válido.";
  } else {
    // Si es válido, se borra el mensaje de error
    errorCorreo.textContent = "";
  }
});

// Validación en tiempo real del campo "contraseña"
password.addEventListener("input", () => {
  // Si la contraseña tiene menos de 6 caracteres, se muestra un mensaje de error
  if (password.value.length < 6) {
    errorPassword.textContent = "La contraseña debe tener al menos 6 caracteres.";
  } else {
    // Si es válida, se borra el mensaje de error
    errorPassword.textContent = "";
  }
});

// Validación final al intentar enviar el formulario
document.getElementById("formulario").addEventListener("submit", (e) => {
  // Si alguno de los campos es inválido, se detiene el envío y se muestra un aviso
  if (
    nombre.value.trim().length < 3 ||                                 // Validación del nombre
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo.value) ||               // Validación del correo
    password.value.length < 6                                         // Validación de la contraseña
  ) {
    e.preventDefault();                                               // Evita que el formulario se envíe
    alert("Corrige los errores antes de enviar el formulario.");      // Alerta al usuario
  }
});