// --- Obtener el ID de la película desde la URL actual ---
const urlParams = new URLSearchParams(window.location.search); 
// Crea un objeto que permite leer los parámetros que vienen en la URL, por ejemplo: ?id=3
const ropa1Id = urlParams.get('id'); 
// Extrae el valor del parámetro 'id', que en este caso representa el ID de la película a modificar
// --- Obtener referencias a los elementos del formulario ---
const modificarForm = document.getElementById('modificar-form'); 
// Selecciona el formulario usando su ID (donde se mostrarán los datos de la película)
const idInput = document.getElementById('ropa-id'); 
// Campo oculto para guardar el ID de la película (normalmente no lo ve el usuario)
const nombreInput = document.getElementById('nombre'); 
// Campo donde se muestra o edita el nombre de la película
const materialInput = document.getElementById('material'); 
// Campo donde se muestra o edita la descripción de la película
const fechaInput = document.getElementById('fecha'); 
// Campo donde se muestra o edita la fecha de estreno
const colorInput = document.getElementById('color'); 
// Campo donde se selecciona la categoría de la película
const precioInput = document.getElementById('precio'); 
// Campo donde se muestra o edita el precio de la película

// --- Llenar el formulario con los datos de la película según su ID ---
fetch('/ropa/' + peliculaId) 
// Hace una solicitud al servidor para obtener los datos de la película que tiene ese ID
    .then(response => response.json()) 
    // Cuando el servidor responde, convierte esa respuesta en un objeto JSON para poder trabajar con él
    .then(pelicula => {
        // Rellena cada campo del formulario con los datos de la película obtenida
        idInput.value = pelicula.id; 
        nombreInput.value = pelicula.nombre;
        materialInput.value = pelicula.descripcion;
        // Convierte el formato de fecha a "YYYY-MM-DD" para que sea compatible con el campo tipo "date"
        fechaInput.value = pelicula.fecha.split('T')[0]; 
        colorInput.value = pelicula.categoria;
        precioInput.value = pelicula.precio;
    })
    // Si ocurre un error (por ejemplo, no se encuentra la película), lo muestra en la consola
    .catch(error => console.error('Error al obtener datos de la Ropa:', error));
