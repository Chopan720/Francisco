// Función para modificar una película
function modificarRopa(id) {
    // Redirige al usuario a la página 'modificar_pelicula.html'
    // y le agrega el ID de la película como un parámetro en la URL.
    window.location.href = '/modificar_ropa.html?id=' + id;
}
