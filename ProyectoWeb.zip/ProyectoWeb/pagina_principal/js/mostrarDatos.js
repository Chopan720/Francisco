// Esta función se ejecuta automáticamente cuando la página ha terminado de cargarse
window.onload = function () {
    // Se realiza una solicitud HTTP GET al servidor, a la ruta /peliculas, para obtener la lista de películas
    fetch('/ropa')
        // Cuando se recibe la respuesta del servidor, se convierte el contenido a formato JSON
        .then(function(response) {
            return response.json(); // Retorna una promesa con los datos convertidos a objeto JavaScript
        })
        // Una vez que los datos JSON están disponibles, se ejecuta esta función con esos datos
        .then(function(data) {
            // Se obtiene el elemento HTML con el ID 'peliculas-list' (donde se mostrarán las películas)
            var peliculasList = document.getElementById('peliculas-list');
            // Se recorre cada película recibida en el array de datos
            data.forEach(function(pelicula) {
                // Se crea una nueva fila de tabla (etiqueta <tr>)
                var row = document.createElement('tr');
                // Se define el contenido de la fila usando las propiedades de cada película
                row.innerHTML = 
                    '<td>' + pelicula.nombre + '</td>' +
                    '<td>' + pelicula.descripcion + '</td>' +
                    '<td>' + new Date(pelicula.fecha).toLocaleDateString() + '</td>' + // Se formatea la fecha
                    '<td>' + pelicula.categoria + '</td>' +
                    '<td>' + pelicula.precio + '</td>' +
                    '<td>' +
                        // Se agregan botones para eliminar o modificar, cada uno llamando su función con el ID correspondiente
                        '<button onclick="eliminarPelicula(' + pelicula.id + ')">Eliminar</button>' +
                        '<button onclick="modificarPelicula(' + pelicula.id + ')">Modificar</button>' +
                    '</td>';
                // Se agrega la fila creada a la tabla (o lista) que contiene todas las películas
                peliculasList.appendChild(row);
            });
        });
};
